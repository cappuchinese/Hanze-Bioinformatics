#!/usr/bin/env python3
"""
Read atoms from a PDB file and store as list of coordinates, radii and colors (for further processing using pypovray, for example).
"""

__author__ = "Tsjerk Wassenaar + Fenna Feenstra"
import sys
import chem


def read_pdb(filename):
    # open file
    # for each line in the file
    # if the line is an atom (starts with ATOM or HETATM)
    # store the line
    # close the file
    # return the list of atoms


def atoms2spheres(atomlist):
    # for each atom
    # get element and coordinates
    # find radius for element from chem module
    # find color for element
    # add (x, y, z, radius, color) to output list
    # return list


def main(args):
    # Preparation
    # Input: filename (string)
    # Need: atoms
    atoms = read_pdb(filename)

    # Work
    # Input: atoms (list of strings)
    # Need list with coordinates, radii and colors
    spheres = atoms2spheres(atoms)

    # Finish
    # Input list of atoms
    # print first and last

    return 0


if __name__ == "__main__":
    result = main(sys.argv)
    sys.exit(result)






AMINO = "ALA CYS ASP GLU PHE GLY HIS ILE LYS LEU MET ASN PRO GLN ARG SER THR VAL TRP TYR".split()


def atom(atomstring):
    """
    function that returns per line a set of atom characteristics
    """
    name = atomstring[12:16].strip()
    elem = atomstring[77:79].strip()
    residue = atomstring[17:20]
    resnum = atomstring[22:26]
    chain = atomstring[21]
    x = atomstring[30:38]
    y = atomstring[38:46]
    z = atomstring[46:54]
    q = atomstring[54:60]
    b = atomstring[60:66]
    return chain, residue, resnum, name, elem


def read_atoms(pdbfile):
    """
    filter only the lines starting with ATOM or HETATM from a pdb file
    input: pdbfile
    output: atomlist containing per element a set of atom characteristics
            (chain, residue, resnum, name, elem)
    """
    opened = open(pdbfile)
    atoms = []
    # kan in comprehension
    for line in opened:
        if line.startswith("ATOM") or line.startswith("HETATM"):
            atoms.append(atom(line))
    return atoms


def per_residue(atomlist):
    """
    function that counts the total numbers and mass of the residue
    """
    numbers = {}
    mass = {}
    # kan in comprehension
    for residue in AMINO:
        numbers[residue] = 0
        mass[residue] = 0
    numbers["*"] = 0
    mass["*"] = 0

    masses = {}
    # kan in comprehension
    for i in range(len(chem.masses)):
        masses[chem.elements[i]] = chem.masses[i]

    unknown = 0
    # kan in comprehension
    for atom in atomlist:
        if atom[1] in numbers:
            numbers[atom[1]] += 1
            mass[atom[1]] += masses[atom[4]]
        else:
            numbers["*"] += 1
            mass["*"] += masses[atom[4]]

    return numbers, mass


def count(atomlist):
    """ count total chains, residues and atomlist"""
    chains = []
    residues = []
    # kan in comprehension
    for atom in atomlist:
        chains.append(atom[0])
        residues.append(atom[:3])
    return len(set(chains)), len(set(residues)), len(atomlist)


def analyze_atoms(atomlist):
    """
    function that
    input: atomlist with sets of atom characteristics per atom: (chain, residue, resnum, name, elem)
    output: print of total chains, residues and number of atoms,
            total_mass, numbers and mass per residue,
            mass per residue and percentages
    """
    chains, residues, atoms = count(atomlist)
    print("Chains:", chains)
    print("Residues:", residues)
    print("Atoms:", atoms)

    num_per_res, mass_per_res = per_residue(atomlist)
    total_mass = sum(mass_per_res.values())
    percentages = {}
    # kan in comprehension
    for res in mass_per_res:
        percentages[res] = mass_per_res[res] / total_mass

    print("Total mass:", total_mass)
    print(num_per_res)
    print(mass_per_res)
    print(percentages)


def main(args):
    """ read atoms lines from pdbfile and analyze the structure and mass of the atoms"""
    atoms = read_atoms(args[1])
    analyze_atoms(atoms)


main(sys.argv)
