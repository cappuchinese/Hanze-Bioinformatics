#!/usr/bin/env python3

"""
some general description
"""
__author__ = 'Fenna'


import sys
import pydoc


def main(argv=None):
    if len(argv) < 2:
       print(__author__)
       print(pydoc.help(__name__))
    else:
        print(argv)
    return 0
        

if __name__ == "__main__":
    exitcode = main(sys.argv)
    sys.exit(exitcode)
