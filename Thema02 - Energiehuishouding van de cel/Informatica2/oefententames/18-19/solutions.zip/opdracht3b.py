
#!/usr/bin/env python3
"""
Read atoms from a PDB file and store as list of coordinates, radii and colors (for further processing using pypovray, for example).
"""

__author__ = "Fenna Feenstra"

import sys
import chem


def read_pdb(filename):
    """ function that reads pdbfile and fetch the ATOMS and HETAM lines"""
    opened = open(filename)
    atoms = []
    # kan in comprehension
    for line in opened:
        if line.startswith("ATOM") or line.startswith("HETATM"):
            atoms.append(line)
    opened.close()
    return atoms


def find_color(elem):
    """ function that matches color with element"""
    sphere_color = {"C": "grey",
                    "O": "red",
                    "H": "white",
                    "N": "blue",
                    "S": "yellow"}
    if elem in sphere_color:
        return sphere_color[elem]
    else:
        return "magenta"


def fetch(atomstring):
    """Convert a line containing an atom definition to the separate elements"""
    elem = atomstring[77:79].strip()
    x = float(atomstring[30:38].strip())
    y = float(atomstring[38:46].strip())
    z = float(atomstring[46:54].strip())
    rad = [chem.radii[i] for i,j in enumerate(chem.elements) if j == elem]
    col = find_color(elem)
    sphereline = "[{:.3f}, {:.3f}, {:.3f}, {:.2f}, {}]".format(x,y,z, rad[0], col)
    return sphereline


def atoms2spheres(atomlist):
    """ function that returns per line a set of sphere characteristics """
    spheres = []
    for atom in atomlist:
        spheres.append(fetch(atom))
    return spheres


def main(args):
    """The main function (run when run as program)"""
    # Preparation
    filename = args[1]
    atoms = read_pdb(filename)

    spheres = atoms2spheres(atoms)
    print("first: {}".format(spheres[0]))
    print("last : {}".format(spheres[-1]))

    return 0


if __name__ == "__main__":
    exitcode = main(sys.argv)
    sys.exit(exitcode)
